// mapping  between UI controls and Javascript methods. Mwk sure they match up properly
var STSEnvMap = new Array();
STSEnvMap["DEMO"] = 'on';
STSEnvMap["PROD"] = 'off';

//get STS Env.
function getSTSServiceURL() {
    
    if (localStorage.getItem("environment") == STSEnvMap["PROD"]) serviceURL = "https://myspeedtax.com";
    else serviceURL = "https://demo.myspeedtax.com";
    
    return serviceURL;
    
}

function setSTSServiceHeader(xhr) {
    // use session storage variables
    xhr.setRequestHeader("Authorization", getSTSServiceAuth(sessionStorage.getItem("AccountID"), sessionStorage.getItem("Password")));
}

function getSTSServiceAuth(STSUserid, STSPassword) {
    var bytes = Crypto.charenc.Binary.stringToBytes(STSUserid + ':' + STSPassword);
    var base64 = Crypto.util.bytesToBase64(bytes);
    return "Basic " + base64;
}




// creates a popup on the screen 
function setDivPopUpMessage(divtag, msg) {
    
    $("#" + divtag).append('<div data-role="popup" id="errorMsg" align="center" >' + msg + '</div>').trigger('create');
    $('#errorMsg').popup('open');
    $('#errorMsg').on('popupafterclose', function(e) {
        $('#errorMsg').remove();
    });
    
}

// make a sync call to ping method to confirm AccountID, Password and Env( Demo/Prod) combination is correct.
function checkServiceAuth() {
    
    var serviceAuthResponse = {
        status: "fail",
        message: ""
    }
        
   	var serviceURL = getSTSServiceURL();
    var passAuth = false;
    
    $.ajax({
        type: "GET",
        url: serviceURL + "/tx/services/rest/ping",
        beforeSend: setSTSServiceHeader,
        success: function(response) {
            if (response == 'pong') {
                serviceAuthResponse.status = "pass";
                serviceAuthResponse.message = "";
                
            } else {
                serviceAuthResponse.status = "fail";
                serviceAuthResponse.message = "Please check your credentials and make sure you have internet access.";
            }
        },
        error: function(error) {
            serviceAuthResponse.status = "fail";
            serviceAuthResponse.message = "Please check your credentials and make sure you have internet access.";
        },
        async: false
    });
    return serviceAuthResponse;
    
}

// make error messages more user friendly
function errorMessageConversion(msg) {
    
    if (msg == "Service could not resolve the address") msg = "Please correct the address and try again.";
    else if (msg.indexOf("Please use a valid value for CompanyId (EntityId)") != -1) msg = "Make sure the Entity <b>" + localStorage.getItem("STSEntity") + "</b> is valid and  associated with Account <b>" + sessionStorage.getItem("AccountID") + "</b>";
    else if (msg == "") msg = "Generic Error. No details Available!";
    
    return msg;
    
}