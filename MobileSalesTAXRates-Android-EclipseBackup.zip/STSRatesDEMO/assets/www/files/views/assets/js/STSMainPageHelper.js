function findRates(address2) {
    
    
    var serviceURL = getSTSServiceURL();
    
    // create a dummy transaction to get rates.
    
    var jData = {
        "Invoice": {
            "customerIdentifier": "",
            "invoiceDate": "2013-07-25",
            "invoiceNumber": "MobileRatesLookup",
            "invoiceType": "INVOICE",
            "consumersUseTax": "false",
            "vendorDocument": "false",
            "shipFromAddress": {
                "address1": "",
                "address2": address2
            },
            "shipToAddress": {
                "address1": "",
                "address2": address2
            },
            "lineItems": [{
                "lineItemNumber": "0",
                "productCode": "SKU001",
                "quantity": "1",
                "salesAmount": "100",
                "unitPrice": "100"
            }]
        }
    };
    
    
    $.ajax({
        type: "POST",
        url: serviceURL + "/tx/services/rest/entity/" + localStorage.getItem("STSEntity") + "/invoice/calculate",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(jData),
        beforeSend: setSTSServiceHeader,
        success: function(response) {
            
            if (response.CalculateInvoiceResult.resultType == "FAILED_WITH_ERRORS") setDivPopUpMessage("MainPage_putResponse", errorMessageConversion(response.CalculateInvoiceResult.errors.message));
            else setResponse(response.CalculateInvoiceResult.taxes);
        },
        error: function(error) {
            // setDivMessage("MainPage_putResponse", error.responseText);    
            setDivPopUpMessage("MainPage_putResponse", errorMessageConversion(error.responseText));
        }
    });
}


function setResponse(responseObj) {
    
    var content = "<table id='taxResults' class='hovertable'><tr><th>Jurisdiction Level</th><th>Jurisduction Name</th><th>Effective Rate</th></tr>";
    
    
    // if only one tax jurisdiction
    if (!$.isArray(responseObj)) {
        content += '<tr><td >' + responseObj.jurisdictionLevel + '</td><td >' + responseObj.jurisdictionName + '</td><td >' + responseObj.effectiveRate + '</td></tr>';
        
    } else {
        
        $.each(responseObj, function(idx, obj) {
            
            content += '<tr><td >' + obj.jurisdictionLevel + '</td><td >' + obj.jurisdictionName + '</td><td >' + obj.effectiveRate + '</td></tr>';
        });
        
    }
    content += "</table>";
    
    Appery('putResponse').html(content);
    Appery('putResponse').refresh();
    
}